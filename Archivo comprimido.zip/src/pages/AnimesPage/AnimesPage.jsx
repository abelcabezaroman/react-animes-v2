import axios from "axios";
import { useContext } from "react";
import { useState } from "react";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import Gallery from "../../components/Gallery/Gallery";
import Search from "../../components/Search/Search";
import Slider from "../../components/Slider/Slider";
import { LoadingContext } from "../../contexts/LoadingContext";

export default function AnimesPage() {
  const [animes, setAnimes] = useState([]);
  const { setIsLoading } = useContext(LoadingContext);
  // const getAnimes = async () => {
  //     const res = await fetch("https://kitsu.io/api/edge/anime");
  //     const resData = await res.json();
  //     console.log(resData.data);
  // }

  const getAnimes = async (animeSlugFiter = "") => {
    setIsLoading(true);
    const res = await axios.get(
      `https://kitsu.io/api/edge/anime?page%5Blimit%5D=12${animeSlugFiter}`
    );

    setAnimes(res.data.data);
    setIsLoading(false);
  };

  useEffect(() => {
    getAnimes();
  }, []);

  //   useEffect(() => {
  //     console.log("Me inicio");
  //   }, []);

  console.log("me ejecuto muchoo");

  return (
    <div>
      {/* {animes.length !== 0 && <div className="mb-5"><Slider slides={animes}/></div>} */}

      <div className="mb-4">
        <Search
          onSubmit={(data) =>
            getAnimes(
              data.title.length !== 0 ? "&filter%5Bslug%5D=" + data.title : ""
            )
          }
        />
      </div>
      <Gallery list={animes} itemClassName="mb-3 col-12 col-md-4 col-lg-3" />
    </div>
  );
}
